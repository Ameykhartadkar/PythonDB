import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()

cho='y'
while cho=='y':
    try:
        Prodid=input('Enter product id :')
        Company=input('Enter company :')
        Mod=input('Enter model name :')
        Price=input('Enter price :')
        RAM=input('Enter RAM :')
        ROM=input('Enter ROM :')
        Disp=input('Enter display :')
        Rer=input('Enter Rear Camera :')
        Cl=input('Enter color of mobile :')
        Yl=input('Enter year of launch :')
        Pr=input('Enter main purpose of mobile :')
    except:
        print('INVALID INPUT')

    print('-'*40) 
    try:
        curs.execute("insert into MOBILES values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Prodid,Company,Mod,Price,RAM,ROM,Disp,Rer,Cl,Yl,Pr))
        con.commit()
        print('Mobile added successfully')  
    except:
        print('Operation Failed')
        print('Product id is already taken')
    
    curs.execute("select * from MOBILES where Company='%s'"%Company)
    data=curs.fetchall()
    for r in data:
     print(r)
    cho=input('\ndo you want to add another? : (y/n)') 
 
con.close()    
   