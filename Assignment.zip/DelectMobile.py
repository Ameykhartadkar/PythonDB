import pymysql
con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
try:
    prid=input('Enter the product id :')
    curs.execute("select * from MOBILES where Prodid='%s'"%prid)
    data=curs.fetchall()
    if data:
        print(data)
        cho='None'
        cho=input('Do you want to delete data? :(y/n):')
        if cho=='y':
            curs.execute("delete from MOBILES where Prodid='%s'"%prid)
            con.commit()
            print('Deletion Successful')
        else:
            print('Deletion Cancelled')
    else:
        print('Product id not found')
except:
    print('ERROR')                    