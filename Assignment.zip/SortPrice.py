import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
cho='y'
while cho=='y':
  C=input("Enter company :")

  try:
      curs.execute("select * from MOBILES where Company='%s' order by MOBILES.Price"%C)
      d=curs.fetchall()
      if d:
         for r in d:
              print(r)
  except:
      print('error')        
  cho=input('DO you want to fetch another company?:(y/n):')