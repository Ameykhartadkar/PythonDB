import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()


try:
    curs.execute("alter table MOBILES add Purpose varchar(50)")
    con.commit()

    print("column added successfully..")

except Exception as e:
    print("column addition failed",e)
 
con.close()
