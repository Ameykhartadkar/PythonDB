import pymysql
import numpy

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
print('-'*20,'Showing data in Ascending order of price','-'*20)

c=input('Enter the company name of product :')
try:
    curs.execute("select ModelName,Price from MOBILES order by Price")
    data=curs.fetchall()
    
    r=numpy.array(data)
    print(r)  
except:
    print('Error')            