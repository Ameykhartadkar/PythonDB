import numpy
import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
cho='y'
while cho=='y':

   try:
       prid=input('Enter product id of Mobile you want to search :')
      # md=input('Enter model name :')
       curs.execute("select * from MOBILES where Prodid='%s' "%prid)
       data=curs.fetchall()
       if data:
          for r in data:
             print(r[0:4])
            
          cho='None'
          cho=input('Do you want more information? :(y/n):')
          if cho=='y':
             for r in data:
                  print(r)
       else:
          print('Product not found')
   except:
       print("ERROR")
   cho=input('\nDo you want to search another product?:(y/n):')       

