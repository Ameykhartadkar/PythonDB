import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
nm=input('Enter ModelName :')
pr=input('Enter main purpose of mobile:(Social/Gaming/Office):')

try:
    curs.execute("select Company,ModelName from MOBILES where ModelName='%s'"%nm )
    d=curs.fetchall()
    print('Here are mobiles of given ModelName')
    for r in d:
     print(d)
    print('-'*20)
    curs.execute("update MOBILES set Purpose='%s' where ModelName='%s'"%(pr,nm))
    con.commit()
    print("Purpose added successfully")
    curs.execute("select * from MOBILES where ModelName='%s'"%nm)
    d=curs.fetchall()
    for i in d:
     print(i)
except:
    print('error')     