import numpy
import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
try:
      ra=input('Enter RAM :')
      ro=input('Enter ROM :')
      curs.execute("select * from MOBILES where RAM='%s' and ROM='%s'"%(ra,ro))
      d=curs.fetchall()
      if d :
        for r in d:
             print(r[1:4])
      else :
          print('Product not found')    

except :
 print('ERROR')    
con.close()    