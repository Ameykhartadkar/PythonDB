import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()
print('-'*20,'Showing all Mobiles','-'*20)

try:
    #prid=input('Enter thr product id :')
    curs.execute('select * from MOBILES ')
    data=curs.fetchall()
    for r in data:
      print(r)
except:
    print('ERROR')   