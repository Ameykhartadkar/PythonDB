import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')
curs=con.cursor()

prid=input('Enter Product id :')
np=input('Enter new price :')
try:
 curs.execute("select ModelName,Price,RAM,ROM from MOBILES where Prodid='%s'"%prid)
 d=curs.fetchall()
 print('-'*50)
 
 if d: 
     print(d)
     cho='None'
     cho=input('Do you want to update price? :(y/n):')
     if cho=='y':
         curs.execute("update MOBILES set Price='%s' where MOBILES.Prodid='%s'"%(np,prid))
         con.commit()
         print('Price updated successfuly')
     else:
            print('Updation Cancelled')  
     curs.execute("select * from MOBILES where Prodid='%s'"%prid)
     d=curs.fetchall()
     print(d)


 else:
        print('Product not found')
except:
    print('ERROR') 