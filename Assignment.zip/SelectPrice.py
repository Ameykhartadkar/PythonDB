import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()

p=input('Enter price :')
try:
    curs.execute("select * from MOBILES where Price<='%s'"%p)
    d=curs.fetchall()
    if d:
      for r in d:
         print(r[1:4])
      
      cho='None'
      cho=input('Do you want more information about mobiles?:(y/n): ')
      if cho=='y':
         for r in d:
             print(r)   
    else:
      print('Products not found')
except:
    print("ERROR")        
con.close()    