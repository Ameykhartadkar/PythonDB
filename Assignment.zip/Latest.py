import pymysql

con=pymysql.connect(host='b0hh2fx2qgwunxhab6jz-mysql.services.clever-cloud.com',user='u2rds0ftxxf47tzc'
,password='bPWWCQo9hnsDSulFN2mb',database='b0hh2fx2qgwunxhab6jz')

curs=con.cursor()

c=input('Enter company :')
try:
    curs.execute("select Company,ModelName,YOL from MOBILES where Company='%s' order by MOBILES.YOL "%c)
    d=curs.fetchall()
    for r in d:
        print(r)
    cho='None'
    cho=input('Do you want more information? :(y/n):')
    if cho=='y':
        curs.execute("select * from MOBILES where Company='%s' order by MOBILES.YOL "%c)
        e=curs.fetchall()
        for s in e:
            print(s)
except:
    print('Company not found')        